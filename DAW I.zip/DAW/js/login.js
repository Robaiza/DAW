var attempt = 3;

function validate() {
	var usuar = document.getElementById("username").value;
	var password = document.getElementById("password").value;

	if (usuar == "isidro" && password == "1234") {
		alert("Haz iniciado sesión exitosamente Isidro Marroquin");
		window.location = "index.html";
		return false;
	} else {
		attempt --;
	}

	alert("Te quedan " + attempt + " intentos más.")
	if (attempt == 0) {
		document.getElementById("username").disable = true;
		document.getElementById("password").disable = true;
		document.getElementById("submit").disable = true;
	}
}
